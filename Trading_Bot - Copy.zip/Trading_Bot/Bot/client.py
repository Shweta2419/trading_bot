import logging

logger = logging.getLogger(__name__)


class TradingClient:
    def __init__(self, api_client):
        self.client = api_client
        logger.info("Client initialized")

    def place_order(self, order_params):
        try:
            logger.info("Placing order")

            response = self.client.futures_create_order(**order_params)

            logger.info("Order placed successfully")
            logger.info(f"Response: {response}")

            return response

        except Exception as e:
            logger.error(f"Error while placing order: {e}")
            return None
