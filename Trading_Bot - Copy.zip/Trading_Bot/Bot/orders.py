from validators import (
    validate_side,
    validate_order_type,
    validate_quantity,
    validate_price
)

def build_order_params(symbol, side, order_type, quantity, price=None):
    side = validate_side(side)
    order_type = validate_order_type(order_type)
    quantity = validate_quantity(quantity)
    validate_price(price, order_type)

    params = {
        "symbol": symbol.upper(),
        "side": side,
        "type": order_type,
        "quantity": quantity,
    }

    if order_type == "LIMIT":
        params["price"] = price
        params["timeInForce"] = "GTC"

    return params
