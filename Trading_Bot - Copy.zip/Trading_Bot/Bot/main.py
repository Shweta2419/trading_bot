import logging
from orders import BinanceFuturesClient
from client import TradingClient
from logging_config import setup_logging

#  logging setup
setup_logging()
logger = logging.getLogger(__name__)


def main():
    #  API credentials (example)
    API_KEY = "YOUR_API_KEY"
    API_SECRET = "YOUR_API_SECRET"

    # Binance API client
    api_client = BinanceFuturesClient(
        api_key=API_KEY,
        api_secret=API_SECRET
    )

    #  Trading client
    trading_client = TradingClient(api_client)

    #  Order parameters
    order_params = {
        "symbol": "BTCUSDT",
        "side": "BUY",
        "type": "MARKET",
        "quantity": 0.001
    }

    #  Place order
    trading_client.place_order(order_params)


if __name__ == "__main__":
    main()
